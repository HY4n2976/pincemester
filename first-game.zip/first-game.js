// Vászon és kontextus inicializálása
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

// Vászon méretezése
canvas.width = 800;
canvas.height = 600;

// Képek betöltése
const images = {
    sourceBarrel: new Image(),
    targetBarrel: new Image(),
    tube: new Image()
};

images.sourceBarrel.src = 'first-game-pics/wooden-barrel.jpg'; // Forráshordó
images.targetBarrel.src = 'first-game-pics/barrel2.png'; // Célhordó
images.tube.src = 'first-game-pics/tube2.png'; // Cső

// Játékállapot
const gameState = {
    sourceBarrel: { x: 100, y: 250, width: 100, height: 100 }, // Kisebb forráshordó
    targetBarrel: { x: 600, y: 250, width: 100, height: 100 }, // Kisebb célhordó
    tube: { x: 175, y: 325, width: 200, height: 50 }, // Cső kezdőpontja a bal hordó közepén
    isDragging: false,
    tubeEnd: { x: 300, y: 300 } // Cső vége, amit az egérrel mozgatunk
};

// Egér események kezelése
canvas.addEventListener('mousedown', (e) => {
    const { offsetX, offsetY } = e;
    const { tubeEnd } = gameState;

    // Ellenőrzés, hogy az egér a cső végén van-e
    const distance = Math.sqrt(
        (offsetX - tubeEnd.x) ** 2 + (offsetY - tubeEnd.y) ** 2
    );

    if (distance <= 30) {
        gameState.isDragging = true;
    }
});

canvas.addEventListener('mousemove', (e) => {
    if (gameState.isDragging) {
        const { offsetX, offsetY } = e;
        gameState.tubeEnd.x = offsetX;
        gameState.tubeEnd.y = offsetY;
    }
});

canvas.addEventListener('mouseup', () => {
    gameState.isDragging = false;
});

// Játék kirajzolása
function draw() {
    // Vászon törlése
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Forráshordó
    ctx.drawImage(
        images.sourceBarrel,
        gameState.sourceBarrel.x,
        gameState.sourceBarrel.y,
        gameState.sourceBarrel.width,
        gameState.sourceBarrel.height
    );

    // Célhordó
    ctx.drawImage(
        images.targetBarrel,
        gameState.targetBarrel.x,
        gameState.targetBarrel.y,
        gameState.targetBarrel.width,
        gameState.targetBarrel.height
    );

    // Cső kirajzolása
const sourceCenterX = gameState.sourceBarrel.x + gameState.sourceBarrel.width / 2;
const sourceCenterY = gameState.sourceBarrel.y + gameState.sourceBarrel.height / 2;

const tubeAngle = Math.atan2(
    gameState.tubeEnd.y - sourceCenterY,
    gameState.tubeEnd.x - sourceCenterX
);

const tubeLength = Math.sqrt(
    (gameState.tubeEnd.x - sourceCenterX) ** 2 +
    (gameState.tubeEnd.y - sourceCenterY) ** 2
);

// Az eredeti kép arányainak megtartása
const originalTubeWidth = images.tube.width; // Az eredeti kép szélessége
const originalTubeHeight = images.tube.height; // Az eredeti kép magassága
const aspectRatio = originalTubeHeight / originalTubeWidth; // Képarány

// A cső szélessége és magassága az arányok alapján
const tubeWidth = tubeLength; // A cső hossza az egér pozíciójától függ
const tubeHeight = tubeWidth * aspectRatio; // Magasság az arányok alapján

ctx.save();
ctx.translate(sourceCenterX, sourceCenterY);
ctx.rotate(tubeAngle);
ctx.drawImage(images.tube, 0, -tubeHeight / 2, tubeWidth, tubeHeight); // Képarány megtartása
ctx.restore();
    // Üzenet megjelenítése, ha a cső vége a célhordónál van
    const targetCenterX = gameState.targetBarrel.x + gameState.targetBarrel.width / 2;
    const targetCenterY = gameState.targetBarrel.y + gameState.targetBarrel.height / 2;

    const distanceToTarget = Math.sqrt(
        (gameState.tubeEnd.x - targetCenterX) ** 2 +
        (gameState.tubeEnd.y - targetCenterY) ** 2
    );

    if (distanceToTarget <= 50) {
        ctx.font = '24px Arial';
        ctx.fillStyle = '#2ecc71';
        ctx.fillText('Ügyes vagy! A bor tisztább lett', 200, 100);
    }
}

// Játék fő ciklusa
function gameLoop() {
    draw();
    requestAnimationFrame(gameLoop);
}

// Játék indítása a képek betöltése után
images.tube.onload = () => {
    gameLoop();
};